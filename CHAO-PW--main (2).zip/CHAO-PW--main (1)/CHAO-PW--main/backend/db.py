import sqlite3
import sys
from pathlib import Path

# Le decimos a Python dónde está la carpeta DataBase para poder importar de ahí
RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "DataBase"))

from crear_tablas import ruta_db, crear_tablas


def obtener_conexion():
    conexion = sqlite3.connect(ruta_db)
    conexion.row_factory = sqlite3.Row   # permite leer columnas por nombre
    conexion.execute("PRAGMA foreign_keys = ON")
    return conexion